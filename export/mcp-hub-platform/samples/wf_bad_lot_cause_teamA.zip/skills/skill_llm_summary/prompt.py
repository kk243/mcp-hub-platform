PROMPT = """다음 설비별 불량 집계를 보고 원인 후보를 3줄로 요약해줘.\n{candidates}"""
