def run(charts, rule_result, ml_result):
    info = {c["chart_id"]: c for c in charts}
    shift = {r["chart_id"]: r["trend_shift"] for r in ml_result}
    rows = []
    for r in rule_result:
        reasons = r["reasons"] + (["Trend Shift"] if shift.get(r["chart_id"]) else [])
        if reasons:
            c = info[r["chart_id"]]
            rows.append({"chart_id": c["chart_id"], "chart_name": c["chart_name"], "item": c["item"],
                         "ng_reason": ", ".join(reasons)})
    return rows
