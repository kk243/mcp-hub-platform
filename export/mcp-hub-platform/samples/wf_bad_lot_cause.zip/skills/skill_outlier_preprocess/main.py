import pandas as pd


def run(bad_lots, eqp_history):
    df = pd.DataFrame(bad_lots).merge(pd.DataFrame(eqp_history), on="lot_id")
    stats = df.groupby("eqp_id")["qty"].agg(["sum", "count"]).reset_index()
    limit = stats["sum"].mean() + 2 * stats["sum"].std()
    return stats[stats["sum"] > limit].to_dict("records")
