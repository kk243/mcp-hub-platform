def run(candidates):
    lines = ["# 불량 원인 후보", ""]
    for c in candidates:
        lines.append(f"- {c['eqp_id']}: 불량 {c['sum']}건 / LOT {c['count']}개")
    return "\n".join(lines)
