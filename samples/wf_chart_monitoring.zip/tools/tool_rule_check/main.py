import pandas as pd


def run(charts, response):
    df = pd.DataFrame(response)
    result = []
    for c in charts:
        v = df[df["chart_id"] == c["chart_id"]]["value"]
        reasons = []
        if v.empty:
            reasons.append("Data 누락")
        else:
            if ((v > c["spec_usl"]) | (v < c["spec_lsl"])).any():
                reasons.append("Spec out")
            center = (c["spec_usl"] + c["spec_lsl"]) / 2
            if (v > center).mean() > 0.9 or (v < center).mean() > 0.9:
                reasons.append("편측")
        result.append({"chart_id": c["chart_id"], "reasons": reasons})
    return result
