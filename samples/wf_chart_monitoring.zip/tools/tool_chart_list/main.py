from lake_client import query


def run(user_id):
    sql = "SELECT chart_id, chart_name, item, spec_usl, spec_lsl FROM smartTAS.MY_CHART WHERE user_id = :u"
    return query(sql, u=user_id)
