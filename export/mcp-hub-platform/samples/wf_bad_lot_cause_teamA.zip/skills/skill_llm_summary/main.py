from llm_client import chat

from .prompt import PROMPT


def run(candidates):
    return chat(PROMPT.format(candidates=candidates))
