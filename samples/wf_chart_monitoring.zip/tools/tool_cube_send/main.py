import os

import requests


def run(ng_rows, channel_id):
    lines = [f"[이상 Chart {len(ng_rows)}건]"] + [f"- {r['chart_name']}: {r['ng_reason']}" for r in ng_rows]
    resp = requests.post(os.environ["CUBE_WEBHOOK"], json={"channel": channel_id, "text": "\n".join(lines)},
                         timeout=30)
    resp.raise_for_status()
    return resp.json()
