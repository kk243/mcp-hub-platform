import joblib
import pandas as pd

MODEL = joblib.load("models/trend_shift.pkl")


def run(response):
    df = pd.DataFrame(response)
    feats = df.groupby("chart_id")["value"].agg(["mean", "std", "min", "max"]).reset_index()
    feats["trend_shift"] = MODEL.predict(feats[["mean", "std", "min", "max"]])
    return feats[["chart_id", "trend_shift"]].to_dict("records")
