from tools.tool_cube_send.main import run as cube_send
from tools.tool_save_postgres.main import run as save_postgres


def run(ng_rows, channel_id):
    save_postgres(ng_rows)
    return cube_send(ng_rows, channel_id)
