import os
from datetime import date

import psycopg2


def run(ng_rows):
    with psycopg2.connect(os.environ["PG_DSN"]) as conn, conn.cursor() as cur:
        cur.executemany(
            "INSERT INTO chart_ng (base_date, chart_id, chart_name, item, ng_reason) VALUES (%s, %s, %s, %s, %s)",
            [(date.today(), r["chart_id"], r["chart_name"], r["item"], r["ng_reason"]) for r in ng_rows],
        )
    return len(ng_rows)
