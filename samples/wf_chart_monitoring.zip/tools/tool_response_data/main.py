from lake_client import query


def run(charts, base_date):
    sql = """
        SELECT chart_id, ts, value FROM smartTAS.RESPONSE_DATA
         WHERE chart_id IN :ids AND ts >= :d - INTERVAL '30' DAY
    """
    return query(sql, ids=tuple(c["chart_id"] for c in charts), d=base_date)
