import os

import oracledb


def run(start_date, end_date):
    conn = oracledb.connect(dsn=os.environ["MES_DSN"], user=os.environ["MES_USER"],
                            password=os.environ["MES_PASSWORD"])
    sql = """
        SELECT b.lot_id, b.qty, h.step_id
          FROM MES.BAD_LOT b JOIN MES.LOT_HIST h ON b.lot_id = h.lot_id
         WHERE b.bad_date BETWEEN :s AND :e
    """
    with conn.cursor() as cur:
        cur.execute(sql, s=start_date, e=end_date)
        cols = [c[0].lower() for c in cur.description]
        return [dict(zip(cols, r)) for r in cur.fetchall()]
