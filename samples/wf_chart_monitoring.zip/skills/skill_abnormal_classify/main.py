from tools.tool_ml_trend_shift.main import run as ml_trend_shift
from tools.tool_ng_summary.main import run as ng_summary
from tools.tool_rule_check.main import run as rule_check


def run(charts, response):
    return ng_summary(charts, rule_check(charts, response), ml_trend_shift(response))
