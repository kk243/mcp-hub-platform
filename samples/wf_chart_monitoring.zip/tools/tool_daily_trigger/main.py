from apscheduler.schedulers.blocking import BlockingScheduler


def run(job):
    sched = BlockingScheduler(timezone="Asia/Seoul")
    sched.add_job(job, "cron", hour=7, minute=0)
    sched.start()
