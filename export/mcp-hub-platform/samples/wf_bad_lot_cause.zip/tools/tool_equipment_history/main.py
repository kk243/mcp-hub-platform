import requests

EQP_API = "http://eqp-api.internal/history"


def run(lot_ids):
    resp = requests.post(EQP_API, json={"lot_ids": lot_ids}, timeout=30)
    resp.raise_for_status()
    return resp.json()["rows"]
