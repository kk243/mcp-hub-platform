from tools.tool_chart_list.main import run as chart_list
from tools.tool_response_data.main import run as response_data


def run(user_id, base_date):
    charts = chart_list(user_id)
    return charts, response_data(charts, base_date)
